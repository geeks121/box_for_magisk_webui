<?php
$clashlogs = "run/runs.log";
$pid = "run/box.pid";
$moduledir = "../modules/box_for_magisk";
#header("Refresh:5");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$action = $_REQUEST['actionButton'];
	switch ($action) {
		case "disable":
			$myfile = fopen("$moduledir/disable", "w") or die("Unable to open file!");
			break;
		case "enable":
			unlink("$moduledir/disable");
			break;
	}
}
$p = $_SERVER['HTTP_HOST'];
$x = explode(':',$p);
$host = $x[0];
?>
<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Dashboard - Zona</title>
    <link rel="canonical" href="index.html">
    
    <!-- Bootstrap core CSS -->
	<link href="webui/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="webui/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Favicons -->
	<link rel="apple-touch-icon" href="webui/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
	<link rel="icon" href="webui/assets/img/favicons/yacd-128.png" sizes="32x32" type="image/png">
	<link rel="icon" href="webui/assets/img/favicons/yacd-128.png" sizes="16x16" type="image/png">
	<link rel="manifest" href="webui/dist/js/manifest.json">
	<link rel="mask-icon" href="https://getbootstrap.com/docs/5.1/webui/assets/img/favicons/safari-pinned-tab.svg" color="#7952b3">
	<link rel="icon" href="https://getbootstrap.com/docs/5.1/webui/assets/img/favicons/favicon.ico">
	<meta name="theme-color" content="#7952b3">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }
      body {
  	display: flex;
  	align-items: center;
  	padding-top: 40px;
  	padding-bottom: 60px;
  	background: #fff;
	  background: url('webui/assets/img/favicons/bg.png');
	  background-size: cover;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
      .mb-4 { -webkit-filter: drop-shadow(5px 5px 5px #222222); filter: drop-shadow(5px 5px 5px #222222); }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="webui/dist/css/signin.css" rel="stylesheet">
  </head>
  <body class="text-center">
    
	<main class="form-signin">
	
    <img class="mb-4" src="webui/assets/img/favicons/yacd-128.png" alt="" width="72" height="72" onclick="location.href='http://<?php echo $host; ?>:9999'">
		<div class="container">
			<div class="row">
				<button type="button" class="btn btn-lg btn-secondary" onclick="window.open('http://<?php echo $host; ?>:9090/ui/#/proxies')">
				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16">
				<path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146zM2.5 14V7.707l5.5-5.5 5.5 5.5V14H10v-4a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v4H2.5z"/>
				</svg>
				</button>
			</div>
		</div>
		<hr>
		<div class="row">
			<form class="btn-group" method="POST" action="">
				<button type="button" class="btn btn-lg btn-secondary" onclick="window.open('file.php')">
				<svg class="w-6 h-6" fill="none" stroke="currentColor" width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
					<path stroke-linecap="round" stroke-linejoin="round"  stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
				</svg>
				</button>
				<?php if (file_exists($pid)) { ?>
				<button type="submit" value="disable" class="btn btn-lg btn-danger" name="actionButton" onclick="showToast()">
				<svg class="w-6 h-6" fill="none" stroke="currentColor" width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
				</svg>
				</button>
				<?php } else { ?>
				<button type="submit" value="enable" class="btn btn-lg btn-danger" name="actionButton" onclick="showToast()">
				<svg class="w-6 h-6" fill="none" stroke="currentColor" width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
				</svg>
				</button>
				<?php } ?>
				<button type="button" class="btn btn-lg btn-secondary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
				<svg class="w-6 h-6" fill="none" stroke="currentColor" width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
				</svg>
				</button>
			</form>
		</div>
		<hr>
		<div class="container">
			<div class="row">
				<button type="button" class="btn btn-lg btn-secondary" onclick="window.open('executed.php')">
        <i class="icon-folder"></i>
          <span class="icon-folder"></span>
          <style>
          .icon-folder {
            display: inline-block;
            width: 18px;
            height: 18px;
            background-image: url("data:image/svg+xml;utf8,<svg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><path stroke='currentColor' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z'/></svg>");
            background-repeat: no-repeat;
            background-size: cover;
          }
          </style>
    		</button>
  		</div>
		</div>
		<hr>
		<div class="container">
			<div class="row">
				<button type="button" class="btn btn-lg btn-secondary" onclick="window.open('/webui/monitor/')">
				<svg class="w-6 h-6" fill="none" stroke="currentColor" width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
				</svg>
				</button>
			</div>
		</div>
		<hr>
		<div class="container">
			<div class="row">
				<button type="button" class="btn btn-lg btn-primary" onclick="window.open('https://t.me/trick_ngirit')">
				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telegram" viewBox="0 0 16 16">
					<path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.287 5.906c-.778.324-2.334.994-4.666 2.01-.378.15-.577.298-.595.442-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294.26.006.549-.1.868-.32 2.179-1.471 3.304-2.214 3.374-2.23.05-.012.12-.026.166.016.047.041.042.12.037.141-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8.154 8.154 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629.093.06.183.125.27.187.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.426 1.426 0 0 0-.013-.315.337.337 0 0 0-.114-.217.526.526 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09z"/>
				</svg>
				</button>
			</div>
		</div>
		<!-- Modal -->
		<div class="modal modal-secondary modal-sm fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
			<div class="modal-dialog modal-primary modal-dialog-centered modal-dialog-scrollable">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="staticBackdropLabel">Clash Logs</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<ul class="modal-body list-group" style="text-align:left;">
  					<?php
					  $file = fopen("$clashlogs", "r");
					  while (!feof($file)) {
					  		$log = str_replace('"','',fgets($file));
							echo nl2br($log);
					  }
					  ?>
					</ul>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
	</main>
  </body>
</html>
